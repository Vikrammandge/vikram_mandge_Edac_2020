class A2
{
public static void main(String args[])
{
	//hum row karenge
	for(int i=1;i<=9;i++)
	{
		//space marenge
		for(int j=9;j>=i;j--)
		{
			System.out.print(" ");
		}
		//number print
		for(int k=1;k<=i;k++)
		{
			System.out.print(k+" ");
		}
	System.out.println();
	}
}
}