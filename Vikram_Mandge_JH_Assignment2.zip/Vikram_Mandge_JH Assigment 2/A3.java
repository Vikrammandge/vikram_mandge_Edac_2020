class A3
{
public static void main(String args[])
{
	//row 
	for(int i=1;i<=9;i++)
	{
		//Spaces
		for(int j=9;j>=i;j--)
		{
			System.out.print(" ");
		}
		//* karenge abb
		for(int k=1;k<=i;k++)
		{
			System.out.print("* ");
		}
		System.out.println();
	}
}
}