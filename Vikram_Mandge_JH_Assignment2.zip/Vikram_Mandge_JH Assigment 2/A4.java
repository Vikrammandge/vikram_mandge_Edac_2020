class A4
{
	public static void main(String args[])
	{
		//Row takayche
		for(int i=0;i<=8;i++)
		{
			//spacessssss
			for(int j=8;j>=i;j--)
			{
				System.out.print(" ");
			}
			//number
			for(int k=0,p=1;k<=i;k++,p++)
			{
				System.out.print(p);
			}
			//right side wale number
			//for(int l=8;l>=i;l--)
			//for(int m=2;m<=i;m++)
			{
				for(int m=1,l=i;m<=i;m++,l--)
				{
					
					System.out.print(l);
				}
			}
			System.out.println();
		}
	}
}
			