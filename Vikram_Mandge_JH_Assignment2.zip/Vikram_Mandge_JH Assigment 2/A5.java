class A5
{
public static void main(String args[])
{
	for(int i=1,m=9;i<=9;i++,m--)
	//for(int i=9,m=i;i>=1;i--,m++)
	{
		for(int j=9;j>=i;j--)
		//for(int j=1;j<=i;j++)
		{
			System.out.print(" ");
		}
		for(int k=1,l=m;k<=i;k++,l++)
		{
			System.out.print(l);
		}
		for(int o=2,a=8;o<=i;o++,a--)
		{	
			System.out.print(a);
		}
	System.out.println();
	}
}
}